import fs from 'node:fs/promises';import path from 'node:path';import {spawnSync} from 'node:child_process';
import {handoffManifest,exportHashes,verifiedManifest,createDiagnosticServer,HANDOFF_FILES} from './fixed-edb/scripts/serve-iphone-touch.mjs';
const root='/tmp/loading73-independent/stale-root',fixed='/tmp/loading73-independent/fixed-edb';
for(const f of HANDOFF_FILES){await fs.mkdir(path.dirname(path.join(root,f)),{recursive:true});await fs.copyFile(path.join(fixed,f),path.join(root,f));}
process.chdir(root);await fs.writeFile('.gitignore','out/\nwork/\n');spawnSync('git',['add','.']);spawnSync('git',['-c','user.name=Independent','-c','user.email=review@example.invalid','commit','-m','fixed reviewer source']);
const rows=[];const red=spawnSync('node',[fixed+'/scripts/serve-iphone-touch.mjs'],{encoding:'utf8',timeout:3000});rows.push({case:'same unrelated out without build provenance',exit:red.status,error:red.stderr});
await fs.mkdir('work',{recursive:true});await fs.writeFile('work/iphone-build.json',JSON.stringify({source:await handoffManifest(),exportHashes:await exportHashes(),builtAt:'synthetic-test-only'}));
const manifest=await verifiedManifest();const s=await createDiagnosticServer({root,manifest});await new Promise(r=>s.listen(0,'127.0.0.1',r));
try{await fs.writeFile('out/index.html','<body>CHANGED AFTER SERVER START</body>');let startupCheck;try{await verifiedManifest();startupCheck='accepted';}catch(e){startupCheck=e.message;}const u=`http://127.0.0.1:${s.address().port}`;rows.push({case:'export mutation after verification/start',restartCheck:startupCheck,response:await(await fetch(u+'/Loading-museum/?probe=1')).text(),advertised:await(await fetch(u+'/diagnostic/manifest.json')).json()});}finally{await new Promise(r=>s.close(r));}
await fs.writeFile('/tmp/loading73-independent/provenance-recheck.json',JSON.stringify(rows,null,2));console.log(rows.map(r=>({case:r.case,exit:r.exit,restartCheck:r.restartCheck,response:r.response})));
