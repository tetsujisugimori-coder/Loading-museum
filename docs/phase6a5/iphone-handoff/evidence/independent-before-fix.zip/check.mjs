import {createRequire} from 'node:module';import fs from 'node:fs/promises';import assert from 'node:assert/strict';import {createHash} from 'node:crypto';
import {createDiagnosticServer,handoffManifest} from './scripts/serve-iphone-touch.mjs';
const require=createRequire(import.meta.url),pw=require('/tmp/yamanaka-h-resume/repo/node_modules/playwright');
const manifest=await handoffManifest({requireClean:false});const server=await createDiagnosticServer({manifest});await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin=`http://127.0.0.1:${server.address().port}`;
const results={manifest,rows:[],physical:'NOT_TESTED',errors:[]};
const browser=await pw.chromium.launch();
try{for(const kind of ['touch-seal','same-id-seal','early-seal','double-gesture']){
 const ctx=await browser.newContext({viewport:{width:390,height:1000},hasTouch:true});const page=await ctx.newPage();
 await page.goto(origin+'/diagnostic/plain.html?probe=1');
 for(const [k,v]of Object.entries({device:'independent-emulation',os:'Linux',browser:'Chromium',operator:'independent',sessionId:'counterexamples'}))await page.locator(`#iad73 input[name=${k}]`).fill(v);
 await page.locator('#iad73 select[name=inputKind]').selectOption('playwright');await page.locator('#iad73 form button').click();await page.waitForFunction(()=>window.__iad73.state()==='recording');
 const box=await page.locator('#probe-range').boundingBox();
 if(kind==='same-id-seal')await page.evaluate(()=>{const r=document.querySelector('#probe-range');r.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,pointerId:133,pointerType:'touch'}));r.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,pointerId:133,pointerType:'touch'}));document.querySelector('#iad73-seal').dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,pointerId:133,pointerType:'touch'}));});
 else{if(kind!=='early-seal'){await page.touchscreen.tap(box.x+box.width*.75,box.y+box.height/2);if(kind==='double-gesture')await page.touchscreen.tap(box.x+box.width*.6,box.y+box.height/2);}const seal=await page.locator('#iad73-seal').boundingBox();await page.touchscreen.tap(seal.x+seal.width/2,seal.y+seal.height/2);}
 const sealed=await page.evaluate(()=>window.__iad73.report());const before=JSON.stringify(sealed);await page.evaluate(()=>{document.querySelector('#probe-range').value='-99';document.querySelector('#probe-range').dispatchEvent(new Event('blur',{bubbles:true}));});assert.equal(JSON.stringify(await page.evaluate(()=>window.__iad73.report())),before);
 const downs=sealed.events.filter(e=>e.type==='pointerdown'&&e.phase==='capture');if(kind==='touch-seal'||kind==='same-id-seal')assert.equal(downs.length,1);if(kind==='early-seal')assert.equal(downs.length,0);if(kind==='double-gesture')assert.equal(downs.length,2);
 results.rows.push({kind,downs:downs.length,sealed,status:'PASS'});await ctx.close();}
}catch(e){results.errors.push(e.stack);process.exitCode=1;}finally{await browser.close();await new Promise(r=>server.close(r));await fs.writeFile('/tmp/loading73-independent/check.json',JSON.stringify(results,null,2));console.log(JSON.stringify({rows:results.rows.map(r=>({kind:r.kind,downs:r.downs})),errors:results.errors}));}
