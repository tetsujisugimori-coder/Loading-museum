import json,zipfile,hashlib,io
from pathlib import Path
from PIL import Image
root=Path('/tmp/loading73-original-zips'); rows=[]
for a in json.loads((root/'catalog.json').read_text()):
 p=root/f'{a["id"]}.zip'; raw=p.read_bytes(); digest=hashlib.sha256(raw).hexdigest(); assert 'sha256:'+digest==a['digest']; assert len(raw)==a['size_in_bytes']
 z=zipfile.ZipFile(io.BytesIO(raw)); assert z.testzip() is None
 pngs=[]; js=[]
 for n in z.namelist():
  if n.lower().endswith('.png'):
   b=z.read(n); im=Image.open(io.BytesIO(b)); im.load(); pngs.append({'file':n,'size':im.size,'sha256':hashlib.sha256(b).hexdigest()})
  if n.endswith('.json'):
   d=json.loads(z.read(n)); js.append({'file':n,'head':d.get('head') if isinstance(d,dict) else None,'status':d.get('status') if isinstance(d,dict) else None,'keys':list(d)[:20] if isinstance(d,dict) else 'list'})
 rows.append({'id':a['id'],'run':a['workflow_run']['id'],'expectedHead':a['workflow_run']['head_sha'],'zipSHA256':digest,'crc':'PASS','files':len(z.namelist()),'pngs':pngs,'jsons':js})
Path('/tmp/loading73-independent/zip-audit.json').write_text(json.dumps(rows,indent=2)); print(json.dumps([{'id':r['id'],'pngs':len(r['pngs']),'jsons':len(r['jsons']),'heads':list(set(x['head'] for x in r['jsons']))} for r in rows],indent=2))
