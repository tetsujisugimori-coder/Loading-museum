from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from functools import partial
class Handler(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  if path.startswith('/Loading-museum/'): path=path[len('/Loading-museum'):]
  return super().translate_path(path)
ThreadingHTTPServer(('127.0.0.1',4201),partial(Handler,directory=r'C:\Users\tetsu\Documents\Codex\2026-10-29\task-7\loading-museum\out')).serve_forever()
