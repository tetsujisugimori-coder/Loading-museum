from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
import gzip,io,os
class Handler(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  if path.startswith('/Loading-museum/'): path=path[len('/Loading-museum'):]
  return super().translate_path(path)
 def send_head(self):
  path=self.translate_path(self.path)
  if os.path.isdir(path):path=os.path.join(path,'index.html')
  if not os.path.isfile(path): self.send_error(404);return None
  with open(path,'rb') as f:data=gzip.compress(f.read(),mtime=0)
  self.send_response(200);self.send_header('Content-Type',self.guess_type(path));self.send_header('Content-Encoding','gzip');self.send_header('Content-Length',str(len(data)));self.end_headers();return io.BytesIO(data)
ThreadingHTTPServer(('127.0.0.1',4201),partial(Handler,directory=r'C:\Users\tetsu\Documents\Codex\2026-10-29\task-7\loading-museum\out')).serve_forever()
