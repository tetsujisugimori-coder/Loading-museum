import os,sys,subprocess,datetime,json,pathlib,hashlib
root=pathlib.Path.cwd(); dest=root.parent/'native-route-utf8';now=lambda:datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat()
env=os.environ.copy();env.update(PYTHONUTF8='1',PYTHONPATH=os.pathsep.join([str(root.parent/'route-runtime'),str(root.parent/'playwright-python')]),ROUTE_ROOT=str(root/'out'),WAAPI_URL='http://local.invalid/Loading-museum/',WAAPI_CHROMIUM_PATH=r'C:\Users\tetsu\AppData\Local\ms-playwright\chromium-1194\chrome-win\chrome.exe',WAAPI_WEBKIT_PATH=r'C:\Users\tetsu\AppData\Local\ms-playwright\webkit-2215\Playwright.exe',WAAPI_BROWSERS='chromium,webkit',WAAPI_WIDTHS='375,390,765',VERIFY_ENGINES='chromium,webkit',VERIFY_WIDTHS='375,390,765',VERIFY_ROOT=str(root),VERIFY_PHASE='current',VERIFY_OUT=str(dest/'n2.json'),WAAPI_PARTIAL=str(dest/'stage1.json'))
report={'started':now(),'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'runs':[],'delivery':'route fulfill, exact static build bytes; no HTTP transport'}
for name,script in [('observation','scripts/verify-waapi-observation.py'),('stage1','scripts/verify-waapi-stage1.py'),('n2','docs/maintenance/stage2a-repair-20261026/native/verify-coin-cancellation.py'),('layout','scripts/verify-waapi-acceptance-layout.py'),('menu-input',str(root.parent/'menu-input.py'))]:
 env['WAAPI_RESULT']=str(dest/(name+'.json'));env['ROUTE_JOURNAL']=str(dest/(name+'-assets.jsonl'));p=pathlib.Path(script);p=p if p.is_absolute() else root/p;row={'name':name,'started':now(),'script_sha256':hashlib.sha256(p.read_bytes()).hexdigest()};report['runs'].append(row)
 with (dest/(name+'.log')).open('wb') as log:
  try:row['exit']=subprocess.run([sys.executable,str(p)],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=300).returncode
  except subprocess.TimeoutExpired:row['exit']=124;row['timeout_seconds']=300
 row['finished']=now();(dest/'execution.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(name,row['exit'],flush=True)
report['finished']=now();(dest/'execution.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
