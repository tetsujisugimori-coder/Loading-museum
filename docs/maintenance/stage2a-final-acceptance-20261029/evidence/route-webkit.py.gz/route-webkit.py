import pathlib,os,json,hashlib,datetime,traceback
from playwright.sync_api import sync_playwright
from urllib.parse import urlsplit,unquote
root=pathlib.Path.cwd()/'out'; dest=pathlib.Path('../delivery-diagnostic/route-webkit.json');now=lambda:datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat();r={'started':now(),'delivery':'Playwright route fulfill from exact out bytes, no HTTP transport','assets':[],'pageerrors':[],'consoleErrors':[]}
try:
 with sync_playwright() as p:
  b=p.webkit.launch(headless=True,executable_path=r'C:\Users\tetsu\AppData\Local\ms-playwright\webkit-2215\Playwright.exe');r['browser']=b.version;ctx=b.new_context(viewport={'width':375,'height':900});q=ctx.new_page();q.on('pageerror',lambda e:r['pageerrors'].append(str(e)));q.on('console',lambda m:r['consoleErrors'].append(m.text) if m.type=='error' else None)
  def serve(route):
   path=unquote(urlsplit(route.request.url).path);path=path.removeprefix('/Loading-museum/'); path='index.html' if not path else path;file=(root/path).resolve()
   if not file.is_relative_to(root.resolve()) or not file.is_file():r['assets'].append({'url':route.request.url,'status':404});route.fulfill(status=404,body='Not Found');return
   data=file.read_bytes();typ={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'}.get(file.suffix,'application/octet-stream');r['assets'].append({'url':route.request.url,'status':200,'size':len(data),'sha256':hashlib.sha256(data).hexdigest()});route.fulfill(status=200,body=data,content_type=typ)
  ctx.route('http://local.invalid/**',serve);q.goto('http://local.invalid/Loading-museum/',wait_until='networkidle',timeout=10000);r['navigation']='PASS';r['title']=q.title();r['buttons']=q.get_by_role('button',name='サンプル一覧を見る',exact=False).count();q.get_by_role('button',name='サンプル一覧を見る',exact=False).click();r['cards']=q.locator('.waapiSampleCard').count();r['status']='PASS' if r['cards']==47 and not r['pageerrors'] and not r['consoleErrors'] and all(x['status']==200 for x in r['assets']) else 'FAIL';b.close()
except Exception:r['status']='FAIL';r['failure']=traceback.format_exc()
finally:r['finished']=now();dest.write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:r.get(k) for k in ['status','navigation','browser','title','buttons','cards','pageerrors','consoleErrors','failure']},ensure_ascii=False));print('assets',len(r['assets']))
