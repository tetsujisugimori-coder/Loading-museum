import os,json,datetime,traceback
from pathlib import Path
from playwright.sync_api import sync_playwright
now=lambda:datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat()
q=None;r={'started':now(),'engine':'webkit','width':765,'input':'keyboard Enter, wait for native progression, then mouse click','status':'FAIL'}
try:
 with sync_playwright() as p:
  b=p.webkit.launch(headless=True,executable_path=os.environ['WAAPI_WEBKIT_PATH']); r['version']=b.version
  q=b.new_context(viewport={'width':765,'height':900},has_touch=True).new_page(); q.set_default_timeout(10000); errors=[]; q.on('pageerror',lambda e:errors.append(str(e)))
  q.goto(os.environ['WAAPI_URL'],wait_until='networkidle'); q.get_by_role('button',name='サンプル一覧を見る',exact=False).click(); q.get_by_label('検索',exact=True).fill('Menu Selection Cursor')
  c=q.locator('.waapiSampleCard').filter(has=q.get_by_role('heading',name='Menu Selection Cursor',exact=True)); c.scroll_into_view_if_needed(); c.get_by_role('button',name='観察モードを開く',exact=True).click()
  o=c.locator('.waapiObservation'); o.scroll_into_view_if_needed(); q.wait_for_function('(n)=>n.dataset.controller!=="inactive" && n.querySelector("[data-observation-target]").getAnimations().length>0',arg=o.element_handle()); o.locator('[data-observation-target]').evaluate('async t=>await t.getAnimations()[0].ready')
  play=o.get_by_role('button',name='再生 / 再開',exact=True); pause=o.get_by_role('button',name='一時停止',exact=True); box=pause.bounding_box(); assert box
  o.evaluate('''n=>{const pause=[...n.querySelectorAll('button')].find(b=>b.textContent==='一時停止');window.actualInput=null;pause.addEventListener('pointerdown',e=>{const a=n.querySelector('[data-observation-target]').getAnimations()[0];window.actualInput={trusted:e.isTrusted,time:a.currentTime,state:a.playState,duration:a.effect.getTiming().duration}}, {once:true,capture:true})}''')
  r['preflight']=q.evaluate('''async()=>{const start=performance.now();await document.fonts.ready;const fonts=performance.now();await new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve)));return {start,fonts,done:performance.now()}}''');q.mouse.move(box['x']+box['width']/2,box['y']+box['height']/2); play.focus(); q.keyboard.press('Enter'); q.wait_for_function("n=>{const a=n.querySelector('[data-observation-target]').getAnimations()[0];return a && a.playState==='running' && a.currentTime>0 && a.currentTime<a.effect.getTiming().duration}",arg=o.element_handle(),timeout=1000); q.mouse.click(box['x']+box['width']/2,box['y']+box['height']/2)
  r['inputObservation']=q.evaluate('actualInput'); r['settled']=o.evaluate('''async n=>{const a=n.querySelector('[data-observation-target]').getAnimations()[0];await a.ready;return {time:a.currentTime,state:a.playState}}'''); r['pageerrors']=errors
  x=r['inputObservation']; y=r['settled']; assert x and x['trusted'] and x['state']=='running' and 0<x['time']<x['duration'] and y['state']=='paused' and abs(x['time']-y['time'])<0.1 and not errors,(x,y,errors)
  r['status']='PASS'; b.close()
except Exception as e:
 r['failure']=str(e);r['traceback']=traceback.format_exc()
 if q:
  try:r['failureSnapshot']=q.evaluate('''()=>{const n=document.querySelector('.waapiObservation'),a=n?.querySelector('[data-observation-target]')?.getAnimations()[0];return {at:performance.now(),state:a?.playState,time:a?.currentTime,duration:a?.effect.getTiming().duration,controller:n?.dataset.controller}}''')
  except Exception as capture:r['snapshotError']=str(capture)
finally:r['finished']=now();Path(os.environ['WAAPI_RESULT']).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(r['status']);raise SystemExit(0 if r['status']=='PASS' else 1)
