import json,os,pathlib,hashlib,datetime
from urllib.parse import urlsplit,unquote
from playwright.sync_api import Browser
original=Browser.new_context
root=pathlib.Path(os.environ['ROUTE_ROOT']).resolve(); journal=pathlib.Path(os.environ['ROUTE_JOURNAL'])
def context_with_route(self,*args,**kwargs):
 ctx=original(self,*args,**kwargs)
 def serve(route):
  path=unquote(urlsplit(route.request.url).path).removeprefix('/Loading-museum/');path='index.html' if not path else path;file=(root/path).resolve()
  row={'url':route.request.url,'at':datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat()}
  if not file.is_relative_to(root) or not file.is_file():
   row['status']=404
   with journal.open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
   route.fulfill(status=404,body='Not Found');return
  data=file.read_bytes();row.update(status=200,bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
  with journal.open('a',encoding='utf-8') as f:f.write(json.dumps(row)+'\n')
  typ={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8'}.get(file.suffix,'application/octet-stream')
  route.fulfill(status=200,body=data,content_type=typ)
 ctx.route('http://local.invalid/**',serve)
 return ctx
Browser.new_context=context_with_route
