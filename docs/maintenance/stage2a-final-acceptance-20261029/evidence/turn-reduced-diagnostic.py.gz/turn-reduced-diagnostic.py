import os,datetime,json,traceback,pathlib
from playwright.sync_api import sync_playwright
now=lambda:datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat();r={'started':now(),'engine':'webkit','width':765,'status':'FAIL','pageerrors':[]}
try:
 with sync_playwright() as p:
  b=p.webkit.launch(headless=True,executable_path=os.environ['WAAPI_WEBKIT_PATH']);r['version']=b.version;ctx=b.new_context(viewport={'width':765,'height':900},has_touch=True,reduced_motion='no-preference');q=ctx.new_page();q.on('pageerror',lambda e:r['pageerrors'].append(str(e)));q.set_default_timeout(10000)
  q.goto(os.environ['WAAPI_URL'],wait_until='networkidle');q.get_by_role('button',name='サンプル一覧を見る',exact=False).click();q.get_by_label('検索',exact=True).fill('Turn Order Reflow');c=q.locator('.waapiSampleCard').filter(has=q.get_by_role('heading',name='Turn Order Reflow',exact=True));c.scroll_into_view_if_needed()
  q.evaluate("window.turnMedia=[];window.turnCancels=[];matchMedia('(prefers-reduced-motion: reduce)').addEventListener('change',e=>window.turnMedia.push({matches:e.matches,at:performance.now(),old:(window.turnOld||[]).map((a,id)=>({id,state:a.playState,time:a.currentTime,duration:a.effect.getTiming().duration}))}))")
  c.get_by_role('button',name='HASTE',exact=True).click();q.wait_for_function("()=>document.querySelector('.gameTurn ol').getAnimations({subtree:true}).some(a=>a.playState==='running')",timeout=5000)
  r['before']=q.evaluate("()=>{window.turnOld=document.querySelector('.gameTurn ol').getAnimations({subtree:true});turnOld.forEach((a,id)=>a.addEventListener('cancel',()=>turnCancels.push({id,at:performance.now(),state:a.playState,time:a.currentTime})));return turnOld.map(a=>({state:a.playState,time:a.currentTime,duration:a.effect.getTiming().duration}))}")
  assert r['before'] and all(a['state']=='running' and a['time']<a['duration'] for a in r['before']),r['before']
  q.emulate_media(reduced_motion='reduce');q.wait_for_function("()=>turnMedia.some(x=>x.matches)",timeout=5000)
  try:q.wait_for_function("()=>turnOld.every(a=>a.playState==='idle') && turnCancels.length===turnOld.length",timeout=1500)
  finally:r['after']=q.evaluate("()=>({at:performance.now(),media:turnMedia,cancels:turnCancels,old:turnOld.map(a=>({state:a.playState,time:a.currentTime}))})")
  assert r['after']['media'][0]['matches'] and len(r['after']['media'][0]['old'])==len(r['before']) and all(a['state']=='running' and a['time']<a['duration'] for a in r['after']['media'][0]['old']) and len(r['after']['cancels'])==len(r['before']) and not r['pageerrors'] and all(a['state']=='idle' and a['time'] is None for a in r['after']['old']);r['status']='PASS';b.close()
except Exception:r['failure']=traceback.format_exc()
finally:r['finished']=now();pathlib.Path(os.environ['WAAPI_RESULT']).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(r['status']);raise SystemExit(0 if r['status']=='PASS' else 1)
