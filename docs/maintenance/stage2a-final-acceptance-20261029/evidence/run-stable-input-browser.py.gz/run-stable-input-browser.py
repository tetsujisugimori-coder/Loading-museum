import os,sys,subprocess,datetime,json,pathlib,hashlib
root=pathlib.Path.cwd();dest=root.parent/'stable-input-browser';dest.mkdir(exist_ok=True);now=lambda:datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat()
env=os.environ.copy();env.update(PYTHONUTF8='1',PYTHONPATH=os.pathsep.join([str(root.parent/'route-runtime'),str(root.parent/'playwright-python')]),ROUTE_ROOT=str(root/'out'),WAAPI_URL='http://local.invalid/Loading-museum/',WAAPI_CHROMIUM_PATH=r'C:\Users\tetsu\AppData\Local\ms-playwright\chromium-1194\chrome-win\chrome.exe',WAAPI_WEBKIT_PATH=r'C:\Users\tetsu\AppData\Local\ms-playwright\webkit-2215\Playwright.exe',VERIFY_ROOT=str(root),VERIFY_PHASE='final-event-synchronized')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tracked=['app/components/WaapiExpandedPreviews.tsx','app/components/WaapiSampleGallery.tsx','app/components/WaapiGameObservation.tsx','app/globals.css','tests/waapi-game-regressions.test.tsx']
report={'started':now(),'delivery':'route fulfill exact build bytes; not HTTP','source':{p:sha(root/p) for p in tracked},'build':{str(p.relative_to(root/'out')):sha(p) for p in (root/'out').rglob('*') if p.is_file() and p.suffix in ['.html','.js','.css']},'runs':[]}
cases=[('menu-input375',str(root.parent/'menu-input-stable375.py'),'webkit','375'),('menu-input390',str(root.parent/'menu-input-stable390.py'),'webkit','390'),('menu-input765',str(root.parent/'menu-input-stable765.py'),'webkit','765')]
for name,script,engine,widths in cases:
 env.update(WAAPI_BROWSERS=engine,WAAPI_WIDTHS=widths,VERIFY_ENGINES=engine,VERIFY_WIDTHS=widths,WAAPI_RESULT=str(dest/(name+'.json')),VERIFY_OUT=str(dest/(name+'.json')),WAAPI_PARTIAL=str(dest/(name+'.json')),ROUTE_JOURNAL=str(dest/(name+'-assets.jsonl')))
 p=pathlib.Path(script);p=p if p.is_absolute() else root/p;row={'name':name,'started':now(),'script_sha256':sha(p),'engine':engine,'widths':widths};report['runs'].append(row)
 with (dest/(name+'.log')).open('wb') as log:
  proc=subprocess.Popen([sys.executable,str(p)],env=env,stdout=log,stderr=subprocess.STDOUT)
  try:row['exit']=proc.wait(timeout=300)
  except subprocess.TimeoutExpired:
   row['timeout_seconds']=300;subprocess.run(['taskkill','/PID',str(proc.pid),'/T','/F'],stdout=log,stderr=subprocess.STDOUT);proc.wait();row['exit']=124
 row['finished']=now();(dest/'execution.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8');print(name,row['exit'],flush=True)
report['finished']=now();report['sourceAfter']={p:sha(root/p) for p in tracked};report['buildAfter']={str(p.relative_to(root/'out')):sha(p) for p in (root/'out').rglob('*') if p.is_file() and p.suffix in ['.html','.js','.css']};(dest/'execution.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
