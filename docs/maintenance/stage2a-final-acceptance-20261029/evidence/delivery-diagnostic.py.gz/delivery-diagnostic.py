import os,sys,threading,json,pathlib,datetime,time,traceback,hashlib,gzip,io
from http.server import SimpleHTTPRequestHandler,ThreadingHTTPServer
from functools import partial
from playwright.sync_api import sync_playwright
root=pathlib.Path.cwd(); dest=root.parent/'delivery-diagnostic';dest.mkdir(exist_ok=True); now=lambda:datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat()
r={'started':now(),'hypothesis':'HTTP asset transfer or document lifecycle stalls before existing verifier can navigate; inspect each event separately','head':'997c6927cfa51af7ff3e002a46f7019a03654da4','requests':[],'server':[],'pageerrors':[],'consoleErrors':[]}
class Handler(SimpleHTTPRequestHandler):
 def translate_path(self,path):
  if path.startswith('/Loading-museum/'):path=path[len('/Loading-museum'):]
  return super().translate_path(path)
 def log_message(self,format,*args):r['server'].append({'at':now(),'message':format%args})
 def send_head(self):
  path=self.translate_path(self.path)
  if os.path.isdir(path):path=os.path.join(path,'index.html')
  if not os.path.isfile(path):self.send_error(404);return None
  with open(path,'rb') as f:data=gzip.compress(f.read(),mtime=0)
  self.send_response(200);self.send_header('Content-Type',self.guess_type(path));self.send_header('Content-Encoding','gzip');self.send_header('Content-Length',str(len(data)));self.end_headers();return io.BytesIO(data)
server=ThreadingHTTPServer(('127.0.0.1',4202),partial(Handler,directory=str(root/'out')));thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
try:
 with sync_playwright() as p:
  b=p.chromium.launch(headless=True,executable_path=r'C:\Users\tetsu\AppData\Local\ms-playwright\chromium-1194\chrome-win\chrome.exe');r['browser']=b.version
  q=b.new_page(viewport={'width':375,'height':900});events={}
  def req(x):
   item={'url':x.url,'method':x.method,'started':now(),'type':x.resource_type};r['requests'].append(item);events[id(x)]=item
  def response(x):
   item=events.get(id(x.request));
   if item is not None:item.update(status=x.status,headers=x.headers,responseAt=now())
  def finish(x):
   item=events.get(id(x));
   if item is not None:item.update(finished=now())
  def failed(x):
   item=events.get(id(x));
   if item is not None:item.update(failed=now(),error=x.failure)
  q.on('request',req);q.on('response',response);q.on('requestfinished',finish);q.on('requestfailed',failed);q.on('pageerror',lambda e:r['pageerrors'].append(str(e)));q.on('console',lambda m:r['consoleErrors'].append(m.text) if m.type=='error' else None)
  try:q.goto('http://127.0.0.1:4202/Loading-museum/',wait_until='commit',timeout=10000);r['commit']='PASS'
  except Exception as e:r['commit']='FAIL';r['commitError']=str(e)
  for state in ['domcontentloaded','load','networkidle']:
   try:q.wait_for_load_state(state,timeout=10000);r[state]='PASS'
   except Exception as e:r[state]='FAIL';r[state+'Error']=str(e)
  try:r['dom']=q.evaluate('''()=>({ready:document.readyState,title:document.title,buttons:document.querySelectorAll('button').length,scripts:[...document.scripts].map(x=>x.src),bodyLength:document.body?.innerText.length,waapi:!!document.querySelector('.waapiSampleCard')})''')
  except Exception as e:r['domError']=str(e)
  try:r['htmlHash']=hashlib.sha256(q.content().encode('utf-8')).hexdigest()
  except Exception as e:r['htmlError']=str(e)
  b.close()
except Exception as e:r['fatal']=traceback.format_exc()
finally:
 server.shutdown();server.server_close();r['finished']=now();(dest/'diagnostic.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:r.get(k) for k in ['browser','commit','domcontentloaded','load','networkidle','dom','pageerrors','consoleErrors','fatal']},ensure_ascii=False));print('requests',len(r['requests']),'finished',sum('finished'in x for x in r['requests']),'failed',sum('failed'in x for x in r['requests']))
