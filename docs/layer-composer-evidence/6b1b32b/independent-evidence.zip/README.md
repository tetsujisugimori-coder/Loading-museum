# Layer Composer independent review evidence

This directory separates pre-final findings from final-candidate execution. Do not substitute older HEAD results for final CI.

## Findings and rechecks

- P2-01: Native opacity slider released outside its input left the editor transaction pending in Chromium. Input-level pointer capture alone did not fix the observed path. The window pointerup fallback closes only the matching opacity gesture and retains cancellation. Same real-pointer reproduction passed in Chromium and WebKit after repair; see capture-fix-retest.json.
- P2-02: Evidence validation accepted numeric strings and Infinity for counts, and did not bind a complete file set to every cell. Exact numeric counts and exact per-cell export/screenshot/trace filenames plus hashes now reject these failures. See evidence-negative.mjs and source negative tests.

## Independent calculations

Literal opaque colors [100,150,200] and [200,100,50] were composited in a 1px geometry. Manually derived expected RGB: Normal [200,100,50], Multiply [78,59,39], Screen [222,191,211], Normal 50% [150,125,125]. WebKit matched exactly; Chromium differed by at most one quantization level. Expected values did not call production renderer or scalar helper.

## Reproduction

Use the repository's pinned package lock and external Playwright 1.56.1 / pngjs 7.0.0. Set PLAYWRIGHT_MODULE and PNG_MODULE to those modules, optional WEBKIT_EXECUTABLE for a compatible WebKit launcher. Start from a clean fixed-HEAD checkout and run:

1. npm ci
2. node scripts/build-layer-composer.mjs
3. node independent-browser.mjs CHECKOUT_DIRECTORY EVIDENCE_DIRECTORY
4. node evidence-negative.mjs CHECKOUT_DIRECTORY

independent-browser.mjs launches isolated contexts at 375/1280px and DPR1/2 in Chromium/WebKit. It decodes the downloaded 600x400 PNG and compares its complete RGBA hash across all four conditions within each browser. It repeats the outside-pointer-release and Escape/late-input cases in all eight contexts. Cross-browser antialiasing identity is not asserted.

No physical iPhone, physical touch, VoiceOver, or A5 native range defect resolution is claimed. No merge or deployment was performed by the reviewer.
